Unzip this archive onto the c: drive of the host PC.

place the source files into the "LEDinBottle" folder.

Start CCS6 and select the workspace folder.

Newer versions of CCS will require that the project files be updated.

Alternately, start a blank CCS project and copy the source files into
the new project's source folder.
